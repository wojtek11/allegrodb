package tree;

public class MainTree {
public static void main(String args[]) {
 
// tworzymy w�ze� b�d�cy korzeniem
TreeCategories<String> korzen = new TreeCategories<String>(null, "kategorie");
 
// dodajemy do niego kolejne w�z�y
TreeCategories<String> n1 = korzen.addChild("Antyki i Sztuka");
TreeCategories<String> n2 = korzen.addChild("Bilety");    
TreeCategories<String> n3 = korzen.addChild("biuro i turystyka");


 
n1.addChild("antyki");
n1.addChild("zegary");    
n1.addChild("");           
 
n2.addChild("bi�uteria");     
 
n1.addChild("sportowe");
n2.addChild("turystyczne");     
 
// tworzymy drzewo i wskazujemy, kt�ry w�ze� jest korzeniem
Tree<String> drzewo = new Tree<String>(korzen);
System.out.println(n1.getChildren());
System.out.println(n3);
System.out.println(n1.getParent());

}
}