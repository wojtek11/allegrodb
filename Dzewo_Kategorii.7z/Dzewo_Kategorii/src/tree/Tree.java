package tree;

/**
.* Klasa Tree<T> - drzewo
* @author kozik
*/
class Tree<T> {
// referencja do w�z�a b�d�cego korzeniem
private TreeCategories<T> root;
 
public Tree() {
// brak korzenia
root = null;
}
 
public Tree(TreeCategories<T> root) {
// ustawiamy korze�
this.root = root;
}
}