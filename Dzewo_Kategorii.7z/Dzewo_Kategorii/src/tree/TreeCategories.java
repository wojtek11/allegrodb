package tree;

import java.util.LinkedList;

/**
02.* Klasa TreeCtegories<T> - w�ze� drzewa
03.* @author kozik
04.*/
class TreeCategories<T> {
private T data;
private TreeCategories<T> parent;
private LinkedList<TreeCategories<T>> children;

public TreeCategories() {
parent = null;
children = new LinkedList<TreeCategories<T>>();
}
 
public TreeCategories(TreeCategories<T> parent) {
this();
this.parent = parent;
}
 
public TreeCategories(TreeCategories<T> parent, T data) {
this(parent);
this.data = data;
}
 
public TreeCategories<T> getParent(){
return parent;
}
 
public void setParent(TreeCategories<T> parent) {
this.parent = parent;
}
 
public T getData() {
return data;
}
 
public void setData(T data) {
this.data = data;
}
 
public int getDegree() {
return children.size();
}
 
public boolean isLeaf(){
return children.isEmpty();
}
 
public TreeCategories<T> addChild(TreeCategories<T> child) {
child.setParent(this);
children.add(child);
return child;
}
 
public TreeCategories<T> addChild(T data) {
TreeCategories<T> child = new TreeCategories<T>(this, data);
children.add(child);
return child;
}
 
public TreeCategories<T> getChild(int i){
return children.get(i);
}
 
public TreeCategories<T> removeChild(int i) {
return children.remove(i);
}
 
public void removeChildren() {
children.clear();
}
 
public LinkedList<TreeCategories<T>> getChildren() {
return children;
}
 
public TreeCategories<T> getLeftMostChild() {
if (children.isEmpty()) return null;
return children.get(0);
}
 
public TreeCategories<T> getRightSibling() {
if (parent != null) {
LinkedList<TreeCategories<T>> parentsChildren = parent.getChildren();
int pos = parentsChildren.indexOf(this);
if (pos < (parentsChildren.size()-1))
return parentsChildren.get(pos+1);
}
return null;
}
 
public String toString() {
return data.toString();
}
}